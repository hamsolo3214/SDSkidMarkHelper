Go to the ModWork folder `C:\Users\<USER>\Documents\Trackmania2020\Skins\Stadium\ModWork` (if it doesn't exist, create it (this also requires a game restart)).
Put the `CustomSkids` folder in the `ModWork` folder (see: `ModWorkFolder.PNG`).
The plugin swaps these around depending on your speed and drift, if you have old custom skids, you can put them in `DefaultSkids` or backup/delete them. The plugin should delete any existing if they are left there.

Put the `SDSkidMarkHelper.op` file in your in your plugins folder, which should be `C:\Users\<USER>\OpenplanetNext\Plugins` (see: `PluginLocation.PNG`).

You should now be ready to go.